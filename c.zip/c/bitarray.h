typedef unsigned int bit;
void   set(bit A[], int k);
void clear(bit A[], int k);
int    get(bit A[], int k);
void printBinaryArray(bit A[], int size);
