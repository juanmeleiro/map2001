bool   adjacent(bit* P[],  int i,        int j                  );
void     search(int start, bit* graph[], int size, int result[] );
void printGraph(bit* A[],  int size                             );
